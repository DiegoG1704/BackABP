const { config } = require("dotenv");


config()
module.exports = {
    PORT: 3000,
    DB_USER: 'garcgfzx_MasSalud',
    DB_HOST: 'localhost',
    DB_PASSWORD: 'Qe7bqWl[I2Z,',
    DB_DATABASE: 'garcgfzx_ABP'
    // PORT: 3000,
    // DB_USER: 'root',
    // DB_HOST: 'localhost',
    // DB_PASSWORD: '',
    // DB_DATABASE: 'interfaz'
  };
